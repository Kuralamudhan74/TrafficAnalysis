-- Traffic Bottleneck Database Backup
-- Created: 2026-01-24T13:29:19.383530
-- Tables: algorithms, backups

-- Table: algorithms (5 rows)
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (1, 'LIM', 'Monte Carlo simulation with probabilistic spread for traffic jam prediction', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Linear Independent Cascade', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (2, 'LTM', 'Threshold-based activation model for congestion spread', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Linear Threshold Model', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (3, 'SIR', 'Epidemic model for traffic congestion with recovery', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Susceptible-Infected-Recovered', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (4, 'SIS', 'Epidemic model allowing re-infection for persistent congestion', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Susceptible-Infected-Susceptible', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (5, 'GREEDY', 'Iterative selection algorithm for top-K bottleneck identification', FALSE, '2026-01-24T07:29:59.347346', '2026-01-21T11:56:40.536829', 'Greedy Bottleneck Finder', 'optimization', 'temp', '{}', '2026-01-24T07:29:59.347346');

-- Table: backups (0 rows)

